#include "Star.hpp"

Star::Star() : GameEntity(".", 2, -1, -1, 1) {}

Star::~Star() {}

Star::Star(int h, int w) : GameEntity(".", 2, h, w, 1) {}

Star::Star(Star const &src)
{
  *this = src;
}

Star &Star::operator=(Star const &rhs)
{
  if (this != &rhs)
  {
    this->_shape = ".";
    this->_color = 2;
    this->_h = rhs.getH();
    this->_w = rhs.getW();
    this->_life = rhs.getLife();
  }
  return (*this);
}

void  Star::hit(GameEntity *stars, int i)
{
  (void)stars;
  (void)i;
}