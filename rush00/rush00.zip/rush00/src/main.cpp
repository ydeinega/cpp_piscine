#include <time.h>
#include "Game.hpp"


int main()
{
   Game  game;
  int   ch;

  while ((ch = getch()))
  {
    game.draw_all();
    if (game.gameOver() == false)
    {
      game.update();
      if (ch == 'q') //gameover condition
      {
        wclear(game.win);
        mvwprintw(game.win , 1, 1, "Game over. Press ANY KEY to exit");
        box(game.win, 0, 0);
        wrefresh(game.win);
        nocbreak();//exit half-delay mode
        cbreak();//no need to push enter
        getch();
        endwin();
        return 0;
      }
      if (ch == KEY_UP || ch == KEY_DOWN || ch == KEY_LEFT || ch == KEY_RIGHT)
        game.player.move(ch);
      if (ch == ' ')
        game.player.shoot(game.bullets, game._nBullet, game.win);
    }
    else
    {
        wclear(game.win);
        mvwprintw(game.win , 1, 1, "Game over. YOU LOST! Press ANY KEY to exit");
        box(game.win, 0, 0);
        wrefresh(game.win);
        nocbreak();//exit half-delay mode
        cbreak();//no need to push enter
        getch();
        endwin();
        return 0;
    }
  }
}





//   while(game.gameOver() == false)
//   {
//     loops = 0;
//     while( clock() > next_game_tick && loops < MAX_FRAMESKIP)
//     {
//       game.update();

//       next_game_tick += SKIP_TICKS;
//       loops++;
//     }

//     // game.display();
//   }
// }





